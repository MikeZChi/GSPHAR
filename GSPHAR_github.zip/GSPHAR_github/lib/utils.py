# -*- coding: utf-8 -*-
"""
Created on Sun Jul  6 19:47:48 2025

@author: MC
"""
import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
import numpy as np
import pandas as pd
from statsmodels.tsa.vector_ar.var_model import VAR
from scipy.linalg import eig
from scipy.linalg import sqrtm


# DY: volatility spillover
def compute_spillover_index(data, horizon, lag, scarcity_prop, standardized=True):
    model = VAR(data)
    results = model.fit(maxlags=lag)
    
    A = results.ma_rep(maxn=horizon)
    
    Sigma = results.sigma_u 
    K = Sigma.shape[0]
    
    num = np.zeros((K, K))  
    den = np.zeros(K)      
    
    for h in range(horizon):
        Phi_h = A[h]
        num += (Phi_h @ Sigma) ** 2 
        den += np.diag(Phi_h @ Sigma @ Phi_h.T)
    num = num / np.diag(Sigma)[np.newaxis, :]
    gfevd = num / den[:, np.newaxis]
    
    if standardized:
        gfevd = gfevd / gfevd.sum(axis=1, keepdims=True)
    spillover_matrix = gfevd.T
    spillover_matrix *= 100 
    
    results_df = pd.DataFrame(spillover_matrix, columns=results.names, index=results.names)
    
    vsp_df_sparse = results_df.copy()
    threshold = pd.Series(results_df.values.flatten()).quantile(scarcity_prop)
    vsp_df_sparse[vsp_df_sparse < threshold] = 0
    vsp_np_sparse = vsp_df_sparse.values
    
    np.fill_diagonal(vsp_np_sparse, 0)
    
    return vsp_np_sparse
    
# MagNet laplacian construction
def magnet_laplacian(A, q, norm = True):
    A_s = (A + A.T)/2
    D_s = np.diag(np.sum(A_s, axis=1)) + 1e-6 * np.eye(A.shape[0])
    pi = np.pi
    theta_q = 2 * pi * q * (A - A.T)
    H_q = A_s * np.exp(1j*theta_q)
    if norm == True:
        D_s_inv = np.linalg.inv(D_s)
        D_s_inv_sqrt = sqrtm(D_s_inv)
        L = np.eye(len(D_s)) - (D_s_inv_sqrt @ A_s @ D_s_inv_sqrt) * np.exp(1j*theta_q)
    else:
        L = D_s - H_q

    return L

# Laplacian decomposition and formatting
def eig_dec(L):
    eigenvalues, eigenvectors = eig(L)
    Lambda = eigenvalues.real
    U_dega = eigenvectors
    U = eigenvectors.T.conj()

    # Sort the eigenvalues (Lambda) and get the indices of the sorted order
    sorted_indices = np.argsort(Lambda)  # Sort in ascending order

    # Reorder Sigma, U, and U_dega
    Lambda_sorted = Lambda[sorted_indices]  
    U_sorted = U[:, sorted_indices]   
    U_dega_sorted = U_dega[sorted_indices, :]

    # Convert sorted Sigma into a diagonal matrix
    Lambda_matrix_sorted = np.diag(Lambda_sorted)

    Lambda = Lambda_matrix_sorted
    U_dega = U_dega_sorted
    U = U_sorted
    return U, Lambda, U_dega

# Normalized adj mx
def norm_adj(A):
    D = np.diag(np.sum(A, axis=1))
    A_tensor = torch.tensor(A, dtype=torch.float32)
    D_tensor = torch.tensor(D, dtype=torch.float32)
    D_tilde_tensor =  torch.pow(D_tensor, -0.5)
    D_tilde_tensor = torch.diag_embed(torch.diagonal(D_tilde_tensor))
    norm_A_tensor = torch.matmul(torch.matmul(D_tilde_tensor, A_tensor), D_tilde_tensor)
    return norm_A_tensor

def GLASSO_Precision(subret, alpha):
    """
    subret: (n_samples, n_assets) array
    alpha:  float       – fixed L1‐penalty
    """
    from sklearn.covariance import GraphicalLasso
    model = GraphicalLasso(alpha=alpha, # 0.074
                           max_iter=100,
                           tol=1e-4)
    model.fit(subret)
    P = model.precision_
    # adjacency = nonzero pattern minus self‐loops
    adj = (P != 0).astype(float) - np.eye(P.shape[0])
    sparsity = adj.mean()
    return adj

def Pearson_corr(X, thresh=-1):
    corr = np.corrcoef(X, rowvar=False)
    np.fill_diagonal(corr, 0.0)
    # build 0/1 adjacency *without* diagonal ones
    if thresh > 0.001:
        adj = (corr > thresh).astype(float)
    elif thresh==0.0:
        adj = corr * (corr > thresh)
    else:
        adj = abs(corr)
        adj = adj * (adj > 0.3)
    sparsity = adj.mean()
    return adj

def graph_laplacian(A, normalized=True):
    # ensure array and float for divisions
    A = np.asarray(A, dtype=float)
    n = A.shape[0]
    if A.shape[1] != n:
        raise ValueError("A must be a square matrix")

    # degree vector and matrix
    deg = A.sum(axis=1)
    D = np.diag(deg)+ 1e-6 * np.eye(A.shape[0])

    if not normalized:
        L = D - A
    else:
        # avoid division by zero on isolated nodes
        with np.errstate(divide='ignore'):
            d_inv_sqrt = 1.0 / np.sqrt(deg)
        d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.0
        D_inv_sqrt = np.diag(d_inv_sqrt)
        L = np.eye(n) - D_inv_sqrt @ A @ D_inv_sqrt
    return L


## Save model
def save_model(name, task_name, evaluation, model, best_loss_val = None):
    if not os.path.exists(f'results/{task_name}/{evaluation}/models/'):
            os.makedirs(f'results/{task_name}/{evaluation}/models/')
    # Prepare the model state dictionary
    config = {
        'model_state_dict': model.state_dict(),
        'loss': best_loss_val
    }
    # Save the model state dictionary
    torch.save(config, f'results/{task_name}/{evaluation}/models/{name}.tar')
    return

## Load model
def load_model(name, task_name, evaluation, model):
    checkpoint = torch.load(f'results/{task_name}/{evaluation}/models/{name}.tar', map_location='cpu')
    model.load_state_dict(checkpoint['model_state_dict'])
    loss = checkpoint['loss']
    print(f"Loaded model: {name}")
    return model, loss

def train_eval_GSPHAR(name, task_name, evaluation, model, dataloader_train, dataloader_test, num_epochs = 100, tol = 50, lr = 0.01):
    # Fix random seed
    torch.manual_seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(42)
    
    best_loss_val = 1000000
    patience = 0
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.OneCycleLR(optimizer, max_lr = lr, steps_per_epoch=len(dataloader_train),
                                                    epochs = num_epochs, three_phase=True)
    model.to(device)
    if evaluation == 'mae':
        criterion = nn.L1Loss()
    else:
        criterion = nn.MSELoss()
    criterion = criterion.to(device)
    model.train()
    for epoch in range(num_epochs):
        for x_lag1, x_lag5, x_lag22, y in dataloader_train:
            x_lag1 = x_lag1.to(device) # [batch_size, #markets]
            x_lag5 = x_lag5.to(device) # [batch_size, #markets, 5]
            x_lag22 = x_lag22.to(device) # [batch_size, #markets, 22]
            y = y.to(device)
            optimizer.zero_grad()
            output = model(x_lag1, x_lag5, x_lag22)
            loss = criterion(output, y)
            loss.backward()
            # Update parameters
            optimizer.step()
            # Update scheduler: this scheduler is designed to be updated after each batch.
            scheduler.step()
        
        # Evaluate model
        valid_loss = evaluate_GSPHAR(model, criterion, dataloader_test)

        if valid_loss < best_loss_val:
            best_loss_val = valid_loss
            patience = 0
            save_model(name, task_name, evaluation, model, best_loss_val)

            final_conv1d_lag5_weights = None
            final_conv1d_lag22_weights = None
        else:
            patience = patience + 1
            if patience >= tol:
                print(f'early stopping at epoch {epoch+1}.')
                break
            else:
                pass
    return best_loss_val, final_conv1d_lag5_weights, final_conv1d_lag22_weights

def evaluate_GSPHAR(model, criterion, dataloader_test):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    criterion = criterion.to(device)
    valid_loss = 0
    model.eval()
    with torch.no_grad():
        for x_lag1, x_lag5, x_lag22, y in dataloader_test:
            x_lag1 = x_lag1.to(device)
            x_lag5 = x_lag5.to(device)
            x_lag22 = x_lag22.to(device)
            y = y.to(device)
            output = model(x_lag1, x_lag5, x_lag22)
            loss = criterion(output, y)
            valid_loss = valid_loss + loss.item()
    valid_loss = valid_loss/len(dataloader_test)
    return valid_loss

def train_eval_GNNHAR(name, task_name, evaluation, model, dataloader_train, dataloader_test, A, num_epochs = 200, tol = 50, lr = 0.01):
    torch.manual_seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(42)

    best_loss_val = 1000000
    patience = 0
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.OneCycleLR(optimizer, max_lr = lr, steps_per_epoch=len(dataloader_train),
                                                    epochs = num_epochs, three_phase=True)
    model.to(device)
    if evaluation == 'mae':
        criterion = nn.MSELoss()
    else:
        criterion = nn.MSELoss()
    criterion = criterion.to(device)
    model.train()
    for epoch in range(num_epochs):
        for x,y in dataloader_train:
            x = x.to(device)
            y = y.to(device)
            A = A.to(device)
            optimizer.zero_grad()
            output = model(x, A)
            loss = criterion(output, y)
            loss.backward()
            
            # Update parameters
            optimizer.step()
            
            # Update scheduler: this scheduler is designed to be updated after each batch.
            scheduler.step()
        
        # Evaluate model
        valid_loss = evaluate_GNNHAR(model, A, criterion, dataloader_test)
        
        if valid_loss < best_loss_val:
            best_loss_val = valid_loss
            patience = 0
            save_model(name, task_name, evaluation, model, best_loss_val)
        else:
            patience = patience + 1
            if patience >= tol:
                print(f'early stopping at epoch {epoch+1}.')
                break
            else:
                pass
    return best_loss_val


# Evaluate model
def evaluate_GNNHAR(model, A, criterion, dataloader_test):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    criterion = criterion.to(device)
    valid_loss = 0
    model.eval()
    with torch.no_grad():
        for x,y in dataloader_test:
            x = x.to(device)
            y = y.to(device)
            A = A.to(device)
            output = model(x, A)
            loss = criterion(output, y)
            valid_loss = valid_loss + loss.item()
    valid_loss = valid_loss/len(dataloader_test)
    return valid_loss

def GSPHAR_forecast(model, dataloader_test, market_indices_list, evaluation):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    y_hat_list = []
    y_list = []
    model.eval()
    
    with torch.no_grad():
        for x_lag1, x_lag5, x_lag22, y in dataloader_test:
            x_lag1 = x_lag1.to(device)
            x_lag5 = x_lag5.to(device)
            x_lag22 = x_lag22.to(device)
            y = y.to(device)
            y_hat = model(x_lag1, x_lag5, x_lag22)
           # Append the predicted and actual values to their respective lists
            y_hat_list.append(y_hat.cpu().numpy())
            y_list.append(y.cpu().numpy())
            
            
    y_hat_concatenated = np.concatenate(y_hat_list, axis=0)
    y_concatenated = np.concatenate(y_list, axis=0)
    
    rv_hat = pd.DataFrame(data = y_hat_concatenated, columns = market_indices_list)
    rv_true = pd.DataFrame(data = y_concatenated, columns = market_indices_list)

    pred_df = pd.DataFrame()
    for market_index in market_indices_list:
        pred_column = market_index+'_rv_forecast'
        true_column = market_index+'_rv_true'
        pred_df[pred_column] = rv_hat[market_index]
        pred_df[true_column] = rv_true[market_index]
    
    l = 0
    nob = 0
    if evaluation == 'mae':
        for market_index in market_indices_list:
            pred_key = market_index+'_rv_forecast'
            true_key = market_index+'_rv_true'
            l_market = abs(pred_df[true_key].values - pred_df[pred_key].values).sum()
            l += l_market
            nob += len(pred_df[true_key].values)
    else:
        for market_index in market_indices_list:
            pred_key = market_index+'_rv_forecast'
            true_key = market_index+'_rv_true'
            l_market = ((pred_df[true_key].values - pred_df[pred_key].values)**2).sum()
            l += l_market
            nob += len(pred_df[true_key].values)
    mean_l = l/nob

    return mean_l, pred_df

def GNNHAR_forecast(model, A, dataloader_test, market_indices_list, evaluation):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    y_hat_list = []
    y_list = []
    model.eval()
    
    with torch.no_grad():
        for x,y in dataloader_test:
            x = x.to(device)
            y = y.to(device)
            A = A.to(device)
            y_hat = model(x, A)
           # Append the predicted and actual values to their respective lists
            y_hat_list.append(y_hat.cpu().numpy())
            y_list.append(y.cpu().numpy())
            
            
    y_hat_concatenated = np.concatenate(y_hat_list, axis=0)
    y_concatenated = np.concatenate(y_list, axis=0)
    
    rv_hat = pd.DataFrame(data = y_hat_concatenated, columns = market_indices_list)
    rv_true = pd.DataFrame(data = y_concatenated, columns = market_indices_list)

    pred_df = pd.DataFrame()
    for market_index in market_indices_list:
        pred_column = market_index+'_rv_forecast'
        true_column = market_index+'_rv_true'
        pred_df[pred_column] = rv_hat[market_index]
        pred_df[true_column] = rv_true[market_index]

    l = 0
    nob = 0
    if evaluation == 'mae':
        for market_index in market_indices_list:
            pred_key = market_index+'_rv_forecast'
            true_key = market_index+'_rv_true'
            l_market = abs(pred_df[true_key].values - pred_df[pred_key].values).sum()
            l += l_market
            nob += len(pred_df[true_key].values)
    else:
        for market_index in market_indices_list:
            pred_key = market_index+'_rv_forecast'
            true_key = market_index+'_rv_true'
            l_market = ((pred_df[true_key].values - pred_df[pred_key].values)**2).sum()
            l += l_market
            nob += len(pred_df[true_key].values)
    mean_l = l/nob

    return mean_l, pred_df










