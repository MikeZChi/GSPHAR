# -*- coding: utf-8 -*-
"""
Created on Sun Jul  6 19:47:48 2025

@author: MC
"""
import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset
import torch.nn.functional as F
import torch.nn as nn


import warnings
warnings.filterwarnings('ignore')


def GSPHAR_data_prep(dataset_0, horizon):
    dataset = dataset_0.copy()
    look_back_window = 22
    market_indices_list = dataset.columns.tolist()
    for market_index in market_indices_list:
        for lag in range(look_back_window):
            dataset[market_index + f'_{lag+1}'] = dataset[market_index].shift(lag+horizon)
            
    dataset = dataset.dropna()
    columns_lag1 = [x for x in dataset.columns.tolist() if x[-2:] == '_1']
    columns_lag5 = [x for x in dataset.columns.tolist() if (x[-2]=='_') and (float(x[-1]) in range(1,6))]
    columns_lag22 = [x for x in dataset.columns.tolist() if '_' in x]
    x_columns = columns_lag1 + columns_lag5 + columns_lag22
    y_columns = [x for x in dataset.columns.tolist() if x not in x_columns]
    row_index_order = market_indices_list
    column_index_order_5 = [f'lag_{i}' for i in range(1,6)]
    column_index_order_22 = [f'lag_{i}' for i in range(1,23)]
    
    data_dict = {}
    for date in dataset.index:
        y = dataset.loc[date,y_columns]
    
        x_lag1 = dataset.loc[date,columns_lag1]
        new_index = [ind[:-2] for ind in x_lag1.index.tolist()]
        x_lag1.index = new_index
    
        x_lag5 = dataset.loc[date,columns_lag5]
        # Split the index into market indices and lags
        data_lag5 = {
        'Market': [index.split('_')[0] for index in x_lag5.index],
        'Lag': [f'lag_{index.split("_")[1]}' for index in x_lag5.index],
        'Value': x_lag5.values
        }
        # Convert to DataFrame
        df_lag5 = pd.DataFrame(data_lag5)
        # Pivot the DataFrame
        df_lag5 = df_lag5.pivot(index='Market', columns='Lag', values='Value')

        x_lag22 = dataset.loc[date,columns_lag22]
        # Split the index into market indices and lags
        data_lag22 = {
        'Market': [index.split('_')[0] for index in x_lag22.index],
        'Lag': [f'lag_{index.split("_")[1]}' for index in x_lag22.index],
        'Value': x_lag22.values
        }
        # Convert to DataFrame
        df_lag22 = pd.DataFrame(data_lag22)
        # Pivot the DataFrame
        df_lag22 = df_lag22.pivot(index='Market', columns='Lag', values='Value')
    
        x_lag1 = x_lag1.reindex(row_index_order)
        df_lag5 = df_lag5.reindex(row_index_order)
        df_lag22= df_lag22.reindex(row_index_order)
        df_lag5 = df_lag5[column_index_order_5]
        df_lag22 = df_lag22[column_index_order_22]
        
        dfs_dict = {
            'y': y,
            'x_lag1': x_lag1,
            'x_lag5': df_lag5,
            'x_lag22': df_lag22
        }
        data_dict[date] = dfs_dict    
    return data_dict
   
class GSPHAR_Dataset(Dataset):
   def __init__(self, data_dict):
       self.dict = data_dict

   def __len__(self):
       return len(self.dict.keys())

   def __getitem__(self, idx):
       date = list(self.dict.keys())[idx]
       dfs_dict = self.dict[date]
       y = dfs_dict['y'].values
       x_lag1 = dfs_dict['x_lag1'].values
       x_lag5 = dfs_dict['x_lag5'].values
       x_lag22 = dfs_dict['x_lag22'].values
       
       y_tensor = torch.tensor(y, dtype=torch.float32)
       x_lag1_tensor = torch.tensor(x_lag1, dtype=torch.float32)
       x_lag5_tensor = torch.tensor(x_lag5, dtype=torch.float32)
       x_lag22_tensor = torch.tensor(x_lag22, dtype=torch.float32)
       return x_lag1_tensor, x_lag5_tensor, x_lag22_tensor, y_tensor   

    
   
class GSPHAR(nn.Module):
    def __init__ (self, input_dim, output_dim, hid_dim, filter_size, U, U_dega):
        super(GSPHAR,self).__init__()
        self.U = torch.complex(torch.tensor(U.real, dtype=torch.float32), torch.tensor(U.imag, dtype=torch.float32))
        self.U_dega = torch.complex(torch.tensor(U_dega.real, dtype=torch.float32), torch.tensor(U_dega.imag, dtype=torch.float32))

        self.spatial_process = nn.Sequential(
            nn.Linear(2, 2*hid_dim),
            nn.ReLU(),
            nn.Linear(2*hid_dim, 2*hid_dim),
            nn.ReLU(),
            nn.Linear(2*hid_dim, 2*hid_dim),
            nn.ReLU(),
            nn.Linear(2*hid_dim, 1),
        )
        self.har_real = nn.Linear(input_dim, output_dim, bias=True)
        self.har_imag = nn.Linear(input_dim, output_dim, bias=True)
        
        self._init_xavier()

    def _init_xavier(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                # Xavier uniform
                nn.init.xavier_uniform_(m.weight, gain=nn.init.calculate_gain('relu'))
                # Xavier normal: nn.init.xavier_normal_(m.weight, gain=nn.init.calculate_gain('relu'))
                if m.bias is not None:
                    # biases initialized to zero
                    nn.init.zeros_(m.bias)

    def forward(self, x_lag1, x_lag5, x_lag22):
        # x_lag1.shape = [batch_size, #markets]
        # x_lag5.shape = [batch_size, #markets, 5]
        # x_lag22.shape = [batch_size, #markets, 22]
        device = x_lag1.device
        # move all non-parameter tensors
        self.U      = self.U.to(device)
        self.U_dega = self.U_dega.to(device)

        y_hat = self._fix_conv(x_lag1, x_lag5, x_lag22)
        return y_hat
        
    def _fix_conv(self, x_lag1, x_lag5, x_lag22):
        # Convert RV to complex domain
        x_lag1 = torch.complex(x_lag1, torch.zeros_like(x_lag1))
        x_lag5 = torch.complex(x_lag5, torch.zeros_like(x_lag5))
        x_lag22 = torch.complex(x_lag22, torch.zeros_like(x_lag22))
        
        # Lag-1 processing
        x_lag1 = torch.matmul(self.U_dega, x_lag1.unsqueeze(-1))
        x_lag1 = x_lag1.squeeze(-1)
        
        # Spectral domain operations on lag-5
        x_lag5 = torch.matmul(self.U_dega, x_lag5)
        x_lag5_real = x_lag5.real.mean(dim=-1) # [batch_size, filter_size]
        x_lag5_imag = x_lag5.imag.mean(dim=-1) # [batch_size, filter_size]
        x_lag5 = torch.complex(x_lag5_real, x_lag5_imag)
        
        # Spectral domain operations on lag-5
        x_lag22 = torch.matmul(self.U_dega, x_lag22)
        x_lag22_real = x_lag22.real.mean(dim=-1) # [batch_size, filter_size]
        x_lag22_imag = x_lag22.imag.mean(dim=-1) # [batch_size, filter_size]
        x_lag22 = torch.complex(x_lag22_real, x_lag22_imag) 
        
        # Combine lagged responses in the spectral domain
        lagged_rv_spectral = torch.stack((x_lag1, x_lag5, x_lag22), dim=-1) # [batch_size, filter_size, 3]

        # Apply linear transformation separately to the real and imaginary parts
        y_hat_real = self.har_real(lagged_rv_spectral.real)
        y_hat_imag = self.har_imag(lagged_rv_spectral.imag)
        y_hat_spectral = torch.complex(y_hat_real, y_hat_imag)
        
        # Back to the spatial domain
        y_hat = torch.matmul(self.U, y_hat_spectral)
        y_hat_real = y_hat.real.squeeze(-1) # [batch_size, num_markets]
        y_hat_imag = y_hat.imag.squeeze(-1) # [batch_size, num_markets]
        y_hat_spatial = torch.stack((y_hat_real, y_hat_imag), dim=-1)
        
        # Fuse info in real and imag domains
        y_hat = self.spatial_process(y_hat_spatial)
        return y_hat.squeeze(-1)