import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
import time
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import pandas as pd
import itertools

from lib import utils
from model.GSPHAR import GSPHAR_data_prep, GSPHAR_Dataset, GSPHAR

def main_GSPHAR(train_dataset, test_dataset, A, q, hid_dim, learnable_conv, horizon, evaluation, batch_size, num_epochs, tol, lr):    
    # Fix random seed
    torch.manual_seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(42)
    np.random.seed(42)
        
    # Settings
    if horizon == 1:
        task_name = 'st'
    elif horizon == 5:
        task_name = 'mt'
    else:
        task_name = 'lt'

    model_name = 'GSPHAR'
    
    # Dataset formulation
    train_dict = GSPHAR_data_prep(train_dataset, horizon)
    test_dict = GSPHAR_data_prep(test_dataset, horizon)
    dataset_train = GSPHAR_Dataset(train_dict)
    dataset_test = GSPHAR_Dataset(test_dict)
    
    # Create dataloader
    dataloader_train = DataLoader(dataset_train, batch_size=batch_size, shuffle=True)
    dataloader_test = DataLoader(dataset_test, batch_size=batch_size, shuffle=False)
    
    norm_L = utils.magnet_laplacian(A,q,True)
    U, Lambda, U_dega = utils.eig_dec(norm_L)
        
    # Model specification
    GSPHAR_model = GSPHAR(3, 1, hid_dim, len(market_indices_list), U, U_dega)
        
    loss_val, _, _ = utils.train_eval_GSPHAR(model_name, task_name, evaluation, GSPHAR_model, dataloader_train, dataloader_test, num_epochs, tol, lr)
    trained_GSPHAR = GSPHAR(3, 1, hid_dim, len(market_indices_list), U, U_dega)
    trained_GSPHAR, GSPHAR_l = utils.load_model(model_name, task_name, evaluation, trained_GSPHAR)
    
    loss, pred_df = utils.GSPHAR_forecast(trained_GSPHAR, dataloader_test, market_indices_list, evaluation)
    return loss, pred_df, task_name
   


if __name__ == '__main__':
    # Data processing hyperparameters
    data_address = r'data/rv5_sqrt_24.csv'
    split_prop = 0.7
    horizon = 22
    
    # Model training hyperparameters
    evaluation = 'mse'
    batch_size = 32
    num_epochs = 100
    tol = 50
    lr = 0.01
    q = 0.35
    hid_dim = 8
    
    # Data loading
    data = pd.read_csv(data_address, index_col = 0)*100
    market_indices_list = data.columns.tolist()
    date_list = data.index.tolist()
    train_end_idx = int(len(date_list)*split_prop)
    train_dataset = data.iloc[0:train_end_idx,:]
    test_dataset = data.iloc[train_end_idx:,:]
    

    # Graph formulation
    A = utils.compute_spillover_index(train_dataset.values, horizon, 22, 0.0, standardized=True)
    
    loss_fix, pred_fix_df, task_name = main_GSPHAR(train_dataset, test_dataset, A, q, hid_dim, False, horizon, evaluation, batch_size, num_epochs, tol, lr)
    
    print(f'GSPHAR_fix performance for {task_name} & {evaluation}: {loss_fix}')
    pred_fix_df.to_csv(f'results\{task_name}\GSPHAR_{horizon}.csv', index=False)

    